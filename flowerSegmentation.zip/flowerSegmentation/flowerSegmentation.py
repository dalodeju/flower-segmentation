# Flower Segmentation
# Group 3

import cv2
from matplotlib import pyplot as plt

# read input image
img = cv2.imread('dataset/input_images/easy/easy_1.jpg')

# converting colorspace RGB to LAB
lab_img = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)

# splitting L.A.B into different components
L, A, B = cv2.split(lab_img)

# defining folder locations
L_out = 'imageprocessing-pipeline/easy/easy1/L'
A_out = 'imageprocessing-pipeline/easy/easy1/A/'
B_out = 'imageprocessing-pipeline/easy/easy1/B/'

# writing the L.A.B components to the image processing pipeline
cv2.imwrite(L_out + 'L_out.jpg', L)
cv2.imwrite(A_out + 'A_out.jpg', A)
cv2.imwrite(B_out + 'B_out.jpg', B)

# 5x5 median filtering
L_median = cv2.medianBlur(L, 5)
A_median = cv2.medianBlur(A, 5)
B_median = cv2.medianBlur(B, 5)

# equalising the histogram
L_equalized = cv2.equalizeHist(L_median)
A_equalized = cv2.equalizeHist(A_median)
B_equalized = cv2.equalizeHist(B_median)

# Otsu Thresholding to segment the foreground from background (to be adjusted)
_,L_otsu = cv2.threshold(L_equalized, 125, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
_,A_otsu = cv2.threshold(A_equalized, 125, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
_,B_otsu = cv2.threshold(B_equalized, 125, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

# insert postprocessing pipeline here
#
#
#

# show otsu images (for testing threshold)
cv2.imshow('L', L_otsu)
cv2.imshow('A', A_otsu)
cv2.imshow('B', B_otsu)

# keep windows open
cv2.waitKey(0)
cv2.destroyAllWindows()